import string

from secret import flag
from secret import encrypt

import random

dicts = string.ascii_lowercase +"{}"

key = (''.join([random.choice(dicts) for i in range(4)])) * 8

assert(len(flag) == 32)

assert(len(key) == 32)


cipher = encrypt(flag, key)

print(cipher)

# {mvjk}gbxyiutfchpm}ylm}a}amuxlmg
